/*	$NetBSD: math.h,v 1.5 2003/10/22 11:54:23 kleink Exp $	*/

#include <x86/math.h>
