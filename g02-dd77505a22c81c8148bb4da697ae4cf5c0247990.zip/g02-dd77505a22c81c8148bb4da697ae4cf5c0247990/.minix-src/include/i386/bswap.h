/*      $NetBSD: bswap.h,v 1.4 2008/10/26 06:57:30 mrg Exp $      */

/* Written by Manuel Bouyer. Public domain */

#ifndef _I386_BSWAP_H_
#define	_I386_BSWAP_H_

#include <machine/byte_swap.h>

#define __BSWAP_RENAME
#include <sys/bswap.h>

#endif /* !_I386_BSWAP_H_ */
