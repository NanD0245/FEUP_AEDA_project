/* $NetBSD: joystick.h,v 1.2 2004/07/02 17:15:10 drochner Exp $ */

#include <sys/joystick.h>
