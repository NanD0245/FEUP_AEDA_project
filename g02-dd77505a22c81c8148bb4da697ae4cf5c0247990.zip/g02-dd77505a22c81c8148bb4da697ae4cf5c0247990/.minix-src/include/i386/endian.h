/*	$NetBSD: endian.h,v 1.29 2000/03/17 00:09:20 mycroft Exp $	*/

#include <sys/endian.h>
