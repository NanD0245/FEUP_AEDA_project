/*	$NetBSD: endian_machdep.h,v 1.3 2006/01/30 21:52:38 dsl Exp $	*/

#define _BYTE_ORDER _LITTLE_ENDIAN
