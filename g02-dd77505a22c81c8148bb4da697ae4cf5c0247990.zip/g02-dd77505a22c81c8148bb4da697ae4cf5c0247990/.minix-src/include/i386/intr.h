/*	$NetBSD: intr.h,v 1.37 2003/02/26 21:29:01 fvdl Exp $	*/

#include <x86/intr.h>
