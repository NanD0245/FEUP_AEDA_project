/*	$NetBSD: sysarch.h,v 1.18 2007/04/16 19:12:19 ad Exp $	*/

#include <x86/sysarch.h>
