#ifndef _I386_CONST_H
#define _I386_CONST_H

#define DEFAULT_HZ        60	/* clock freq (software settable on IBM-PC) */

#endif /* #ifndef _I386_CONST_H */
